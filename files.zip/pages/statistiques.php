<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
if (isset($_SESSION['employe'])) {
    ?>


    <div class="container-fluid text-white" style="">
        <div style="border-radius:100px; background-color:DodgerBlue;" class="">
            <hr style="margin-bottom:20px ; background-color:DodgerBlue;" class="line-seprate">
            <p class="h2 text-center text-white text-uppercase font-weight-bold"><a href="./index.php?p=filiere" class="col-md-6 col-lg-3" style="color:white;">Filieres</a>/<a href="./index.php?p=classe" class="col-md-6 col-lg-3" style="color:white;">Classes</a></p>
            <hr class="line-seprate" style="background-color:white" >
        </div>
        <div class="row" style="margin-top:20px">
            <canvas id="myChart" width="230" height="100"></canvas>
            <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

            <script>
                var ctx = document.getElementById('myChart').getContext('2d');
                $.ajax({
                    url: 'controller/gestinStatistiques.php',
                    data: {op: ''},
                    type: 'POST',
                    success: function (data, textStatus, jqXHR) {
                        var x = Array();
                        var y = Array();
                        data.forEach(function (e) {
                            x.push(e.nom);
                            y.push(e.nbr);
                        });
                        showGraph(x, y);
                    },
                    error: function (jqXHR, textStatus, errorThrown) {
                        console.log(textStatus);
                    }
                });
                var haha = [
                    'rgba(255, 99, 132, 0.2)',
                    'rgba(54, 162, 235, 0.2)',
                    'rgba(255, 206, 86, 0.2)',
                    'rgba(255, 222, 0, 0.2)',
                    'rgba(153, 102, 255, 0.2)',
                    'rgba(255, 159, 64, 0.2)',
                    'rgba(255, 99, 132, 0.2)',
                    'rgba(54, 162, 235, 0.2)',
                    'rgba(255, 206, 86, 0.2)',
                    'rgba(75, 192, 192, 0.2)',
                    'rgba(153, 102, 255, 0.2)',
                    'rgba(255, 159, 64, 0.2)',
                    'rgba(255, 99, 132, 0.2)',
                    'rgba(54, 162, 235, 0.2)',
                    'rgba(255, 206, 86, 0.2)',
                    'rgba(75, 192, 192, 0.2)',
                    'rgba(153, 102, 255, 0.2)',
                    'rgba(255, 159, 64, 0.2)',
                    'rgba(255, 99, 132, 0.2)',
                    'rgba(54, 162, 235, 0.2)',
                    'rgba(255, 206, 86, 0.2)',
                    'rgba(75, 192, 192, 0.2)',
                    'rgba(153, 102, 255, 0.2)',
                    'rgba(255, 159, 64, 0.2)'
                ];
                function showGraph(x, y) {
                    var myChart = new Chart(ctx, {
                        type: 'bar',
                        data: {
                            labels: x,
                            datasets: [{
                                    data: y,
                                    backgroundColor: [
                                        'rgba(255, 99, 132, 0.2)',
                                        'rgba(54, 162, 235, 0.2)',
                                        'rgba(255, 222, 0, 0.2)',
                                        'rgba( 9, 112, 84, 0.2)',
                                        'rgba(153, 102, 255, 0.2)',
                                        'rgba(255, 159, 64, 0.2)'
                                    ],
                                    borderColor: [
                                        'rgba(255, 99, 132, 1)',
                                        'rgba(54, 162, 235, 1)',
                                        'rgba(255, 222, 0, 1)',
                                        'rgba(75, 192, 192, 1)',
                                        'rgba(153, 102, 255, 1)',
                                        'rgba(255, 159, 64, 1)'
                                    ],
                                    borderWidth: 1
                                }]
                        },
                        options: {
                            plugins: {
                                legend: {
                                    display: true,
                                    position: 'right',
                                    labels: {
                                        generateLabels: function (chart) {
                                            return chart.data.labels.map(function (label, i) {
                                                return {
                                                    text: label,
                                                    fillStyle: haha[i],
                                                };
                                            });
                                        }
                                    }
                                },
                                title: {
                                    display: true,
                                    text: 'Nombre des classes par filière'
                                }
                            },
                            scales: {
                                y: {
                                    title: {
                                        display: true,
                                        text: 'Numbre of classes'
                                    }
                                },
                                x: {
                                    title: {
                                        display: true,
                                        text: 'Specialities'
                                    }
                                }
                            }
                        }
                    });
                }
            </script>


        </div>

        <?php
    } else {
        header("Location: ../index.php");
    }
    ?>